# tight_subplot_cm
Fork of tight_subplot function: https://www.mathworks.com/matlabcentral/fileexchange/27991-tight-subplot-nh--nw--gap--marg-h--marg-w-

Units are in cm, making it easy to prepare a figure for a paper publication. 
Run example.m and check the paper size of the generated PDF. 
